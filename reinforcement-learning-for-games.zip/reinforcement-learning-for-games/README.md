# 🎮 Reinforcement Learning for Games (Q-Learning Tic-Tac-Toe)

| Field | Detail |
|---|---|
| **Intern Name** | Manas Deo |
| **Intern ID** | CITS7621 |
| **Project Name** | Reinforcement Learning for Games |
| **Internship Duration** | 4-Week Internship Program |
| **Project Scope** | Build a Reinforcement Learning agent that learns to play Tic-Tac-Toe from scratch through trial-and-error (Q-Learning), without any labeled dataset — the agent's "data" is its own gameplay experience. |

---

## 📌 Overview

This project implements a complete **Reinforcement Learning pipeline**
for a classic game — Tic-Tac-Toe. Unlike supervised learning (where a
model learns from a fixed, labeled dataset), this agent learns purely
by **playing the game repeatedly** and receiving rewards:

- `+1` for winning
- `0.5` for a draw
- `-1` for losing
- `-10` for an illegal move (never actually triggered by a well-behaved agent)

The agent uses **tabular Q-Learning** with an epsilon-greedy policy to
balance exploring new moves vs. exploiting what it has already
learned works well.

> **Note on "data":** This project has no static CSV dataset like a
> typical ML project. Instead, the "data" is generated dynamically —
> every training episode (one full game) produces an experience
> record (state, action, reward, next state) that the agent learns
> from immediately. All 50,000 training episodes are also logged to
> `outputs/reports/training_log.csv` for analysis.

---

## 📂 Folder Structure

```
reinforcement-learning-for-games/
│
├── README.md                       # Project documentation (this file)
├── requirements.txt                # Python dependencies
├── .gitignore                      # Files/folders excluded from git
│
├── src/
│   ├── environment.py              # Tic-Tac-Toe game environment (from scratch)
│   ├── q_learning_agent.py         # Q-Learning agent (Q-table, epsilon-greedy, Bellman update)
│   ├── train_agent.py              # Trains the agent over 50,000 episodes
│   ├── evaluate_agent.py           # Evaluates trained agent (greedy) vs random opponent
│   └── play_game.py                # Interactive CLI: play against the trained agent
│
├── models/
│   └── q_table.pkl                 # Trained Q-table (~7,500 state-action entries)
│
├── outputs/
│   ├── plots/
│   │   ├── training_rewards.png    # Moving-average reward curve over training
│   │   └── win_rate_over_time.png  # Win/draw/loss rate across training blocks
│   └── reports/
│       ├── training_log.csv        # Per-episode reward/result/epsilon log
│       └── evaluation_report.txt   # Final win/draw/loss evaluation summary
│
└── docs/
    └── project_report.md           # Week-wise project report
```

---

## ⚙️ Setup Instructions

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd reinforcement-learning-for-games
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the full pipeline** (in order, from inside the project folder)
   ```bash
   cd src
   python train_agent.py       # trains the agent for 50,000 episodes (~1-2 min)
   python evaluate_agent.py    # evaluates the trained agent over 2,000 games
   python play_game.py         # play against the trained agent yourself!
   ```

---

## 🧠 How It Works

| Component | Description |
|---|---|
| **State** | The 3x3 board, represented as a tuple of 9 cells (`1`=agent, `-1`=opponent, `0`=empty) |
| **Action** | Choosing an empty cell index (0-8) to place a mark |
| **Reward** | `+1` win, `0.5` draw, `-1` loss, `-10` illegal move |
| **Policy** | Epsilon-greedy — explores randomly early on, exploits learned knowledge later |
| **Learning Rule** | Q-Learning Bellman update: `Q(s,a) += alpha * (reward + gamma * max(Q(s',a')) - Q(s,a))` |
| **Opponent (training)** | Plays uniformly random valid moves |

---

## 📊 Results

After 50,000 training episodes and evaluation over 2,000 greedy games:

| Metric | Result |
|---|---|
| Win Rate | ~98.8% |
| Draw Rate | ~1.2% |
| Loss Rate | ~0.0% |

See `outputs/reports/evaluation_report.txt` for the exact numbers, and
`outputs/plots/` for the training reward curve and win-rate progression.

---

## 🎮 Example: Playing Against the Agent

```bash
python src/play_game.py
```

```
==================================================
 TIC-TAC-TOE vs. Trained RL Agent
 You are 'O', the agent is 'X'. Agent moves first.
==================================================

Agent's move:
   |   | X
-----------
   |   |
-----------
   |   |

Your move [0, 1, 3, 4, 5, 6, 7, 8]: 4

Your move:
   |   | X
-----------
   | O |
-----------
   |   |
...
```

---

## 📄 Full Report

See [`docs/project_report.md`](docs/project_report.md) for the
detailed week-by-week breakdown of work completed during the 4-week
internship.

---

## 🛠️ Tech Stack

- Python 3 (standard library: `random`, `pickle`, `collections`)
- matplotlib (for training visualizations)
