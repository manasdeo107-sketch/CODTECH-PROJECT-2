"""
environment.py
---------------
A simple Tic-Tac-Toe game environment, built from scratch, that the
Reinforcement Learning agent interacts with.

Board representation:
    A 3x3 board is stored as a flat tuple of 9 cells (index 0-8):
        0  -> empty cell
        1  -> Agent's mark  ("X")
       -1  -> Opponent's mark ("O")

    Board positions map like this:
        0 | 1 | 2
        --+---+--
        3 | 4 | 5
        --+---+--
        6 | 7 | 8

This environment follows the classic RL interface:
    state = env.reset()
    next_state, reward, done, info = env.step(action)

Rewards (from the AGENT's point of view, agent = player 1 / "X"):
    +1   -> agent wins
    -1   -> agent loses
     0.5 -> draw
     0   -> game continues (no reward yet)
    -10  -> illegal move (chosen a cell that is already filled)
"""

import random

AGENT = 1
OPPONENT = -1
EMPTY = 0

# All possible winning lines (rows, columns, diagonals) by cell index
WIN_LINES = [
    (0, 1, 2), (3, 4, 5), (6, 7, 8),   # rows
    (0, 3, 6), (1, 4, 7), (2, 5, 8),   # columns
    (0, 4, 8), (2, 4, 6),              # diagonals
]


class TicTacToeEnv:
    """A minimal Tic-Tac-Toe environment for tabular Q-learning."""

    def __init__(self):
        self.board = [EMPTY] * 9
        self.done = False
        self.winner = None

    def reset(self):
        """Resets the board to empty and returns the initial state."""
        self.board = [EMPTY] * 9
        self.done = False
        self.winner = None
        return self.get_state()

    def get_state(self):
        """Returns the current board as an immutable tuple (used as a Q-table key)."""
        return tuple(self.board)

    def get_valid_actions(self):
        """Returns a list of empty cell indices where a move can legally be made."""
        return [i for i, cell in enumerate(self.board) if cell == EMPTY]

    def check_winner(self):
        """
        Checks the board for a winner.
        Returns AGENT, OPPONENT, 'draw', or None (game still ongoing).
        """
        for a, b, c in WIN_LINES:
            line_sum = self.board[a] + self.board[b] + self.board[c]
            if line_sum == 3 * AGENT:
                return AGENT
            if line_sum == 3 * OPPONENT:
                return OPPONENT
        if EMPTY not in self.board:
            return "draw"
        return None

    def step(self, action, player):
        """
        Applies a move for `player` (AGENT or OPPONENT) at cell `action`.
        Returns (next_state, reward, done, info) -- reward is always
        given from the AGENT's perspective, regardless of who just moved.
        """
        if self.board[action] != EMPTY:
            # Illegal move - heavily penalize and end the episode
            self.done = True
            return self.get_state(), -10, True, {"illegal_move": True}

        self.board[action] = player
        result = self.check_winner()

        if result == AGENT:
            self.done = True
            return self.get_state(), 1, True, {"winner": "agent"}
        elif result == OPPONENT:
            self.done = True
            return self.get_state(), -1, True, {"winner": "opponent"}
        elif result == "draw":
            self.done = True
            return self.get_state(), 0.5, True, {"winner": "draw"}
        else:
            # Game continues, no reward yet
            return self.get_state(), 0, False, {}

    def render(self):
        """Prints the board in a human-readable 3x3 grid."""
        symbols = {AGENT: "X", OPPONENT: "O", EMPTY: " "}
        rows = []
        for r in range(3):
            cells = [symbols[self.board[r * 3 + c]] for c in range(3)]
            rows.append(" " + " | ".join(cells) + " ")
        print(("\n" + "-" * 11 + "\n").join(rows))


def random_opponent_move(env):
    """A simple opponent policy: picks a uniformly random valid move."""
    valid_actions = env.get_valid_actions()
    return random.choice(valid_actions)
