"""
evaluate_agent.py
-------------------
Loads the trained Q-table and evaluates the agent's performance by
playing many games (fully greedy, no exploration) against the random
opponent. Reports win/draw/loss rate and saves a summary report.

Run this AFTER train_agent.py has produced models/q_table.pkl
"""

import os

from environment import TicTacToeEnv, random_opponent_move, AGENT, OPPONENT
from q_learning_agent import QLearningAgent

BASE_DIR = os.path.join(os.path.dirname(__file__), "..")
MODELS_DIR = os.path.join(BASE_DIR, "models")
REPORTS_DIR = os.path.join(BASE_DIR, "outputs", "reports")

N_EVAL_GAMES = 2000


def play_eval_episode(env, agent):
    """Plays one fully-greedy episode (no exploration) and returns the result."""
    state = env.reset()
    done = False
    result = None

    while not done:
        valid_actions = env.get_valid_actions()
        action = agent.choose_action(state, valid_actions, greedy=True)
        state, reward, done, info = env.step(action, AGENT)

        if not done:
            opp_action = random_opponent_move(env)
            state, reward, done, info = env.step(opp_action, OPPONENT)

        if info.get("winner") == "agent":
            result = "agent"
        elif info.get("winner") == "opponent":
            result = "opponent"
        elif info.get("winner") == "draw":
            result = "draw"

    return result


def main():
    model_path = os.path.join(MODELS_DIR, "q_table.pkl")
    if not os.path.exists(model_path):
        raise FileNotFoundError(
            "No trained Q-table found. Run train_agent.py first to create "
            "models/q_table.pkl"
        )

    print(f"Loading trained agent from {model_path} ...")
    agent = QLearningAgent()
    agent.load(model_path)

    env = TicTacToeEnv()
    wins = draws = losses = 0

    print(f"Evaluating agent over {N_EVAL_GAMES} games (greedy policy, no exploration)...\n")

    for _ in range(N_EVAL_GAMES):
        result = play_eval_episode(env, agent)
        if result == "agent":
            wins += 1
        elif result == "draw":
            draws += 1
        elif result == "opponent":
            losses += 1

    win_pct = wins / N_EVAL_GAMES * 100
    draw_pct = draws / N_EVAL_GAMES * 100
    loss_pct = losses / N_EVAL_GAMES * 100

    report = (
        f"Evaluation over {N_EVAL_GAMES} games (greedy policy vs random opponent)\n"
        f"{'-' * 60}\n"
        f"Wins:   {wins:5d}  ({win_pct:5.1f}%)\n"
        f"Draws:  {draws:5d}  ({draw_pct:5.1f}%)\n"
        f"Losses: {losses:5d}  ({loss_pct:5.1f}%)\n"
    )
    print(report)

    os.makedirs(REPORTS_DIR, exist_ok=True)
    report_path = os.path.join(REPORTS_DIR, "evaluation_report.txt")
    with open(report_path, "w") as f:
        f.write(report)
    print(f"Saved evaluation report to {report_path}")


if __name__ == "__main__":
    main()
