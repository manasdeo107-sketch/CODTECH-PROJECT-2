"""
train_agent.py
----------------
Trains the Q-Learning agent by playing many episodes of Tic-Tac-Toe
against a random-move opponent. Over thousands of episodes, the agent
updates its Q-table and gradually learns which moves lead to wins.

Each full turn (agent move + opponent's reply) is treated as a single
Q-learning transition, since the environment always returns rewards
from the agent's perspective.

Outputs produced:
    models/q_table.pkl                      -> trained Q-table
    outputs/reports/training_log.csv        -> per-episode reward/result/epsilon
    outputs/plots/training_rewards.png      -> moving-average reward curve
    outputs/plots/win_rate_over_time.png    -> win/draw/loss rate over training
"""

import os
import csv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from environment import TicTacToeEnv, random_opponent_move, AGENT, OPPONENT
from q_learning_agent import QLearningAgent

BASE_DIR = os.path.join(os.path.dirname(__file__), "..")
MODELS_DIR = os.path.join(BASE_DIR, "models")
PLOTS_DIR = os.path.join(BASE_DIR, "outputs", "plots")
REPORTS_DIR = os.path.join(BASE_DIR, "outputs", "reports")

N_EPISODES = 50000
LOG_EVERY = 500  # how often to print progress to the console


def play_one_episode(env, agent):
    """
    Plays a single training episode (agent vs random opponent) and
    updates the agent's Q-table along the way.
    Returns the total episode reward and the final result string
    ("agent", "opponent", "draw", or "illegal").
    """
    state = env.reset()
    done = False
    total_reward = 0
    result = None

    while not done:
        valid_actions = env.get_valid_actions()
        action = agent.choose_action(state, valid_actions)
        next_state, reward, done, info = env.step(action, AGENT)

        if info.get("illegal_move"):
            result = "illegal"

        if not done:
            # Opponent replies with a random valid move
            opp_action = random_opponent_move(env)
            next_state, reward, done, info = env.step(opp_action, OPPONENT)

        if info.get("winner") == "agent":
            result = "agent"
        elif info.get("winner") == "opponent":
            result = "opponent"
        elif info.get("winner") == "draw":
            result = "draw"

        next_valid_actions = env.get_valid_actions() if not done else []
        agent.update(state, action, reward, next_state, next_valid_actions, done)

        state = next_state
        total_reward += reward

    agent.decay_epsilon()
    return total_reward, result


def main():
    os.makedirs(MODELS_DIR, exist_ok=True)
    os.makedirs(PLOTS_DIR, exist_ok=True)
    os.makedirs(REPORTS_DIR, exist_ok=True)

    env = TicTacToeEnv()
    agent = QLearningAgent()

    log_rows = []
    wins = draws = losses = 0

    print(f"Training Q-learning agent for {N_EPISODES} episodes...\n")

    for episode in range(1, N_EPISODES + 1):
        reward, result = play_one_episode(env, agent)

        if result == "agent":
            wins += 1
        elif result == "draw":
            draws += 1
        elif result == "opponent":
            losses += 1

        log_rows.append({
            "episode": episode,
            "reward": reward,
            "result": result,
            "epsilon": round(agent.epsilon, 4),
        })

        if episode % LOG_EVERY == 0:
            recent = log_rows[-LOG_EVERY:]
            recent_wins = sum(1 for r in recent if r["result"] == "agent")
            win_pct = recent_wins / len(recent) * 100
            print(f"Episode {episode:6d} | epsilon={agent.epsilon:.3f} "
                  f"| win rate (last {LOG_EVERY}): {win_pct:5.1f}%")

    print(f"\nTraining complete. Overall: {wins} wins, {draws} draws, {losses} losses "
          f"out of {N_EPISODES} episodes.")

    # --- Save training log ---
    log_path = os.path.join(REPORTS_DIR, "training_log.csv")
    with open(log_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["episode", "reward", "result", "epsilon"])
        writer.writeheader()
        writer.writerows(log_rows)
    print(f"Saved training log to {log_path}")

    # --- Save trained Q-table ---
    model_path = os.path.join(MODELS_DIR, "q_table.pkl")
    agent.save(model_path)
    print(f"Saved trained Q-table to {model_path} "
          f"({len(agent.q_table)} state-action entries learned)")

    # --- Plot: moving-average reward over episodes ---
    rewards = [r["reward"] for r in log_rows]
    window = 500
    moving_avg = [
        sum(rewards[max(0, i - window):i + 1]) / len(rewards[max(0, i - window):i + 1])
        for i in range(len(rewards))
    ]
    plt.figure(figsize=(8, 4))
    plt.plot(moving_avg, color="teal")
    plt.xlabel("Episode")
    plt.ylabel(f"Reward ({window}-episode moving average)")
    plt.title("Training Reward Over Time")
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "training_rewards.png"))
    plt.close()

    # --- Plot: win/draw/loss rate per block of episodes ---
    block_size = 1000
    blocks = [log_rows[i:i + block_size] for i in range(0, len(log_rows), block_size)]
    win_rates, draw_rates, loss_rates = [], [], []
    for block in blocks:
        n = len(block)
        win_rates.append(sum(1 for r in block if r["result"] == "agent") / n * 100)
        draw_rates.append(sum(1 for r in block if r["result"] == "draw") / n * 100)
        loss_rates.append(sum(1 for r in block if r["result"] == "opponent") / n * 100)

    plt.figure(figsize=(8, 4))
    x = range(1, len(blocks) + 1)
    plt.plot(x, win_rates, label="Win %", color="green")
    plt.plot(x, draw_rates, label="Draw %", color="gray")
    plt.plot(x, loss_rates, label="Loss %", color="red")
    plt.xlabel(f"Training Block (each = {block_size} episodes)")
    plt.ylabel("Percentage")
    plt.title("Win / Draw / Loss Rate Over Training")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_DIR, "win_rate_over_time.png"))
    plt.close()

    print("Saved training plots to outputs/plots/")


if __name__ == "__main__":
    main()
