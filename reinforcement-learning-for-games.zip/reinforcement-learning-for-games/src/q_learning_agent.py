"""
q_learning_agent.py
---------------------
A tabular Q-Learning agent for the Tic-Tac-Toe environment.

Q-Learning is a model-free Reinforcement Learning algorithm that learns
a Q-table mapping (state, action) pairs to expected future rewards.
The agent updates its estimates using the Bellman equation:

    Q(s, a) <- Q(s, a) + alpha * [ r + gamma * max(Q(s', a')) - Q(s, a) ]

Where:
    s      = current state (board configuration)
    a      = action taken (cell index 0-8)
    r      = reward received
    s'     = next state after taking action a
    alpha  = learning rate (how much new information overrides old)
    gamma  = discount factor (how much future rewards matter)

The agent uses an epsilon-greedy policy during training: with
probability epsilon it explores (random move), otherwise it exploits
(picks the best known move so far). Epsilon decays over training so
the agent explores a lot early on and exploits more as it learns.
"""

import random
import pickle
from collections import defaultdict


class QLearningAgent:
    def __init__(self, alpha=0.3, gamma=0.9, epsilon=1.0,
                 epsilon_min=0.05, epsilon_decay=0.9995):
        self.alpha = alpha                    # learning rate
        self.gamma = gamma                    # discount factor
        self.epsilon = epsilon                # exploration rate (starts high)
        self.epsilon_min = epsilon_min        # exploration never drops below this
        self.epsilon_decay = epsilon_decay    # multiplicative decay per episode

        # Q-table: maps (state, action) -> estimated value. Defaults to 0.0
        # for any (state, action) pair we haven't seen yet.
        self.q_table = defaultdict(float)

    def choose_action(self, state, valid_actions, greedy=False):
        """
        Chooses an action using an epsilon-greedy policy.
        If greedy=True, always picks the best known action (used at
        evaluation/play time, not during training).
        """
        if not greedy and random.random() < self.epsilon:
            # Explore: pick a random valid action
            return random.choice(valid_actions)

        # Exploit: pick the action with the highest Q-value for this state
        q_values = [self.q_table[(state, a)] for a in valid_actions]
        max_q = max(q_values)
        # Break ties randomly among equally-good best actions
        best_actions = [a for a, q in zip(valid_actions, q_values) if q == max_q]
        return random.choice(best_actions)

    def update(self, state, action, reward, next_state, next_valid_actions, done):
        """Performs one Q-learning update using the Bellman equation."""
        current_q = self.q_table[(state, action)]

        if done or not next_valid_actions:
            target = reward  # no future reward if the episode has ended
        else:
            future_qs = [self.q_table[(next_state, a)] for a in next_valid_actions]
            target = reward + self.gamma * max(future_qs)

        # Move the current estimate toward the target by a fraction (alpha)
        self.q_table[(state, action)] = current_q + self.alpha * (target - current_q)

    def decay_epsilon(self):
        """Reduces the exploration rate after each episode, down to a floor."""
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)

    def save(self, path):
        """Saves the Q-table (and hyperparameters) to disk using pickle."""
        with open(path, "wb") as f:
            pickle.dump({
                "q_table": dict(self.q_table),
                "alpha": self.alpha,
                "gamma": self.gamma,
                "epsilon": self.epsilon,
            }, f)

    def load(self, path):
        """Loads a previously saved Q-table from disk."""
        with open(path, "rb") as f:
            data = pickle.load(f)
        self.q_table = defaultdict(float, data["q_table"])
        self.alpha = data.get("alpha", self.alpha)
        self.gamma = data.get("gamma", self.gamma)
        self.epsilon = data.get("epsilon", self.epsilon)
